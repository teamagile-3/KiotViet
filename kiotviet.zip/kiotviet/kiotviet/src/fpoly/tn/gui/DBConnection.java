/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fpoly.tn.gui;

import com.sun.jdi.connect.spi.Connection;
import java.lang.System.Logger;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.logging.Level;
import kiotviet.sqlHelper;

/**
 *
 * @author ADMIN
 */
public class DBConnection {
    private static String driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static String dburl="jdbc:sqlserver://localhost;database=QLBanHang";
    private static String username="sa";
    private static String password="123123";
    
  /*  public static Connection getConnection(){
        Connection connection = null;
        try {
            Class.forName("com,microsoft.sqlserver.jdbc.SQLServer");
            String url = "";
            String user = "sa";
            String pass = "123123";
            connection = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            e.printStackTrance();
        }
        return connection;
    }*/
    public static void Dong(Connection con){
        if(con!=null){
            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public static ResultSet GetAllNhanVien(){
        String sql ="Select * from NhanVien";
        return sqlHelper.executeQuery(sql);
    }
    public static void main(String[] args){
        
    }
}
