/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ql.dbo;

import com.sun.jdi.connect.spi.Connection;
import fpoly.tn.gui.DBConnection;
import java.util.concurrent.ExecutionException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import kiotviet.sqlHelper;

/**
 *
 * @author ADMIN
 */
public class BanHang {
    
    private String MaHang, MaVach,TenHang,NhomHang,LoaiHang,
            ThuongHieu,TrongLuong,MoTaKhac,GiaBan,GiaVon;
    private int MaLoaiHang, TonKho;

    public String getMaHang() {
        return MaHang;
    }

     public static ResultSet GetAllNhanVien(){
        String sql ="Select * from NhanVien";
        return sqlHelper.executeQuery(sql);
    }
    public void setMaHang(String MaHang) {
        this.MaHang = MaHang;
    }

    public String getMaVach() {
        return MaVach;
    }

    public void setMaVach(String MaVach) {
        this.MaVach = MaVach;
    }

    public String getTenHang() {
        return TenHang;
    }

    public void setTenHang(String TenHang) {
        this.TenHang = TenHang;
    }

    public String getNhomHang() {
        return NhomHang;
    }

    public void setNhomHang(String NhomHang) {
        this.NhomHang = NhomHang;
    }

    public String getLoaiHang() {
        return LoaiHang;
    }

    public void setLoaiHang(String LoaiHang) {
        this.LoaiHang = LoaiHang;
    }

    public String getThuongHieu() {
        return ThuongHieu;
    }

    public void setThuongHieu(String ThuongHieu) {
        this.ThuongHieu = ThuongHieu;
    }

    public String getTrongLuong() {
        return TrongLuong;
    }

    public void setTrongLuong(String TrongLuong) {
        this.TrongLuong = TrongLuong;
    }

    public String getMoTaKhac() {
        return MoTaKhac;
    }

    public void setMoTaKhac(String MoTaKhac) {
        this.MoTaKhac = MoTaKhac;
    }

    public String getGiaBan() {
        return GiaBan;
    }

    public void setGiaBan(String GiaBan) {
        this.GiaBan = GiaBan;
    }

    public String getGiaVon() {
        return GiaVon;
    }

    public void setGiaVon(String GiaVon) {
        this.GiaVon = GiaVon;
    }

    public int getMaLoaiHang() {
        return MaLoaiHang;
    }

    public void setMaLoaiHang(int MaLoaiHang) {
        this.MaLoaiHang = MaLoaiHang;
    }

    public int getTonKho() {
        return TonKho;
    }

    public void setTonKho(int TonKho) {
        this.TonKho = TonKho;
    }
    
    
    
   /* private Connection conn;
    public BanHang(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databasename = QLBanhang;"
                    + "username = sa;password = 123123");
        }catch(Exception e){
            e.printStackTrace();
        }
      }
    public boolean addBanHang(BanHang bh){
        String sql = "Insert into tblHienThi(MaHang, MaVach,TenHang, NhomHang, LoaiHang)Values(?,?,?,?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, s.getMaHang());
            ps.setString(2, sql);
            ps.set
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public static void main(String[] args){
        new BanHang();
    }*/

    public BanHang(String MaHang, String MaVach, String TenHang, String NhomHang, String LoaiHang, String ThuongHieu, String TrongLuong, String MoTaKhac, String GiaBan, String GiaVon, int MaLoaiHang, int TonKho) {
        this.MaHang = MaHang;
        this.MaVach = MaVach;
        this.TenHang = TenHang;
        this.NhomHang = NhomHang;
        this.LoaiHang = LoaiHang;
        this.ThuongHieu = ThuongHieu;
        this.TrongLuong = TrongLuong;
        this.MoTaKhac = MoTaKhac;
        this.GiaBan = GiaBan;
        this.GiaVon = GiaVon;
        this.MaLoaiHang = MaLoaiHang;
        this.TonKho = TonKho;
    }
}
